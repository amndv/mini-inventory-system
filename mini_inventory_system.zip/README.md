# exercise-js-fetch-mini-inventory-system

Base repository for exercise JavaScript Fetch - Mini Inventory System.


Read the description here:
https://sea-labs-id.git-pages.garena.com/trainers/digi-wiki/docs/fe-stream/javascript/exercise/mini-inventory-system/

Good luck! 🙂